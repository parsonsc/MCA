<div class="rd_metabox">



<?php

$this->select(	'product_hover',

				'Show first gallery photo on hover?',

				array('yes' => 'Yes', 'no' => 'No'),

				''

);

?>







</div>
<div class="rd_metabox">







<?php







$this->select(	'overall_score',







				'Overall Score',







				array(







					'0' => '0',







					'10%' => '0.5',







					'20%' => '1',







					'30%' => '1.5',







					'40%' => '2',







					'50%' => '2.5',







					'60%' => '3',







					'70%' => '3.5',







					'80%' => '4',







					'90%' => '4.5',







					'100%' => '5'







				),







				'Choose a number between 0.5 to 5 (eg. 4.5)'







			);







?>







</div>
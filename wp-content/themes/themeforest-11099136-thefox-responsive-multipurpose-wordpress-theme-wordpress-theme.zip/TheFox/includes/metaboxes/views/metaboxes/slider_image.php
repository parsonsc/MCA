<div class='rd_metabox'>



<?php

$this->textarea(	'image_caption',

				'Image caption'

			);

?>



<?php

$this->textarea(	'image_link',

				'Link for the image </br> ex:</br>

				 http://www.google.com'

			);

?>

</div>
<style type='text/css'>
.rd_metabox { padding: 10px 10px 0px 10px; }
.rd_metabox_field { margin-bottom: 15px; width: 100%; overflow: hidden; }
.rd_metabox_field label { font-weight: 400; float: left; width: 15%; }
.rd_metabox_field .field { float: left; width: 75%; }
.rd_metabox_field input[type=text] { width: 100%; }
</style>
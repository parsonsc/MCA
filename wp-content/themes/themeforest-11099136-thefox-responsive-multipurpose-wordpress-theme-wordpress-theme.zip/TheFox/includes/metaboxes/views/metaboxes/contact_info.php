<div class="rd_metabox">







<?php







$this->text(	'email',







				'Email Address',







				''







			);







?>







<?php







$this->textarea(	'gmap',







				'Google Maps Address'







			);







?>







</div>